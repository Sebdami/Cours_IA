#include "stdafx.h"

#include "Core\Scene.h"

namespace crea
{
	Scene::Scene()
	{

	}

	Scene::~Scene()
	{

	}

} // namespace crea
